import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import './index.css';

class App extends Component {
	constructor(props) {
		super(props);
		this.handleUpdate = this.handleUpdate.bind(this);
		this.state = {
			searchType: 'name',
			sortType: 'name',
			result: 'Init'
		};
	}

	handleUpdate = data => {
		this.setState({result: data});
	}

	handleSubmit = e => {
		e.preventDefault();

		const input = document.getElementById('input').value;
		const linput = input.length;
	
		// Start getString
		let getString = 'http://localhost:3000/src/getRestCountries.php?function=search&request=' + input + '&searchType='
		// Determine Search Type
		getString += (this.state.searchType === 'name' && (linput === 2 || linput === 3)) ? 'code' : this.state.searchType;
		// Determine Sort Type
		getString += '&sortType=' + this.state.sortType;

		// Criteria #4: Form data submitted via JS & displayed without page reloading
		const xhr = new XMLHttpRequest();
		xhr.onreadystatechange = function () {
			if (this.readyState === this.DONE && this.status === 200) {
				document.getElementById('result').innerHTML = xhr.responseText;
				//this.handleUpdate(xhr.responseText);
				console.log(xhr.responseText);
			} else {
				document.getElementById('result').innerHTML = '<center><h3>Generating Results...</h3></center>';
			}
		}
		xhr.open('GET', getString);
		xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
		xhr.send();
	}

    render() {
        return (
            <div className='App'>
				<h2>Rest Countries API</h2>
				<form onSubmit={this.handleSubmit}>
					<div>Search for country by...</div>
					<label>
						<input type='radio' value='name'
						checked={this.state.searchType === 'name'}
						onChange={e => this.setState({ searchType: e.target.value })}
						/>Name/Code
					</label>
					<label>
						<input type='radio' value='full'
						checked={this.state.searchType === 'full'}
						onChange={e => this.setState({ searchType: e.target.value })}
						/>Full Name
					</label>
					<label>
						<input type='radio' value='all'
						checked={this.state.searchType === 'all'}
						onChange={e => this.setState({ searchType: e.target.value })}
						/>List All
					</label>
					<div><br />Search for country by...</div>
					<label>
						<input type='radio' value='name'
						checked={this.state.sortType === 'name'}
						onChange={e => this.setState({ sortType: e.target.value })}
						/>Name
					</label>
					<label>
						<input type='radio' value='pop'
						checked={this.state.sortType === 'pop'}
						onChange={e => this.setState({ searchType: e.target.value })}
						/>Population
					</label>
					<br />
					<input type='text' id='input' placeholder='Afghanistan' autoFocus/>
					<button type='submit' alt='searchCountry'>Submit</button>
				</form>
				<div id='result'>{this.state.result}</div>
			</div>
        );
	}
}

ReactDOM.render(
	<App />,
	document.getElementById('root')
)